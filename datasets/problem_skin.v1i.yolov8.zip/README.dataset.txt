# problem_skin > 2026-05-17 5:11pm
https://universe.roboflow.com/thanhs-workspace-scico/problem_skin

Provided by a Roboflow user
License: CC BY 4.0

