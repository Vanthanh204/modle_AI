# skin > 2026-05-17 5:31pm
https://universe.roboflow.com/thanhs-workspace-scico/skin-4tchc

Provided by a Roboflow user
License: CC BY 4.0

